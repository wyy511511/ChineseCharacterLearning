import SwiftUI




struct Line: Shape {
    var from: CGPoint
    var to: CGPoint

    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: from)
        path.addLine(to: to)
        return path
    }
}


struct NetworkView: View {
    @State private var selection: Node? = nil
    @State private var scale: CGFloat = 1.0
    @GestureState private var magnification: CGFloat = 1.0
    var nodes: [Node]
    var connections: [(Node, Node)] // 添加连接关系

    var body: some View {
        NavigationView {
            GeometryReader { geometry in
                ScrollView([.horizontal, .vertical], showsIndicators: true) {
                    ZStack {
                        // 添加连线
                        ForEach(connections, id: \.0.id) { (fromNode, toNode) in
                            Line(from: fromNode.position, to: toNode.position)
                                .stroke(lineWidth: 1)
                                .foregroundColor(Color.gray)
                        }
                        
                        ForEach(nodes) { node in
                            DraggableView {
                                NodeView(node: node)
                            }
                            .position(node.position)
                            .onTapGesture {
                                selection = node
                            }
                            .background(
                                NavigationLink(
                                    "",
                                    destination: DetailView(node: node, views: node.detailViews),
                                    tag: node,
                                    selection: $selection
                                )
                            )
                        }
                    }
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .scaleEffect(scale * magnification)
                    .gesture(
                        MagnificationGesture()
                            .updating($magnification) { value, state, _ in
                                state = value
                            }
                            .onEnded { value in
                                scale *= value
                            }
                    )
                }
            }
        }
    }
}


struct DraggableView<Content>: View where Content: View {
    @GestureState private var dragOffset = CGSize.zero
    let content: () -> Content

    var body: some View {
        content()
            .offset(dragOffset)
            .gesture(
                DragGesture()
                    .updating($dragOffset) { value, state , _ in state = value.translation}
                    )
    }
}

