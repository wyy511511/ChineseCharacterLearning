import PencilKit
import SwiftUI
import UIKit

struct DrawingView: UIViewRepresentable {
    @Binding var contestantImageURL: URL?
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    func makeUIView(context: Context) -> PKCanvasView {
        let canvasView = PKCanvasView()
        canvasView.tool = PKInkingTool(.pen, color: .black, width: 15)
        canvasView.drawingPolicy = .anyInput
        
        canvasView.delegate = context.coordinator
        return canvasView
    }
    
    func updateUIView(_ uiView: PKCanvasView, context: Context) {
    }
    
    class Coordinator: NSObject, PKCanvasViewDelegate {
        var drawingView: DrawingView
        
        init(_ drawingView: DrawingView) {
            self.drawingView = drawingView
        }
        
        func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
            let drawing = canvasView.drawing
            let image = drawing.image(from: drawing.bounds, scale: UIScreen.main.scale)

            if let imageData = image.pngData() {
                let baseURL = FileManager.default.temporaryDirectory
                let imageURL = baseURL.appendingPathComponent(UUID().uuidString).appendingPathExtension("jpg")
                do {
                    try imageData.write(to: imageURL)
                    drawingView.contestantImageURL = imageURL
                    print("Save image \(imageURL.path) successfully.")
                } catch {
                    print("Save image \(imageURL.path) failed.")
                }
            }
        }
    }
}
