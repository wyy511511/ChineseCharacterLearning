import SwiftUI

struct NodeView: View {
    var node: Node
    @State private var isAnimating = false

    var body: some View {
        ZStack {
            // 添加闪烁环
            Circle()
                .stroke(lineWidth: 2)
                .foregroundColor(node.color)
                .scaleEffect(isAnimating ? 1.5 : 1.0)
                .opacity(isAnimating ? 0 : 1)
                .animation(.easeOut(duration: 1).repeatForever(), value: isAnimating)

            // 原始节点
            Circle()
                .fill(node.color)
                .frame(width: node.size, height: node.size)

            // 添加文字
            Text(node.text)
                .foregroundColor(.white)
        }
        .onAppear {
            isAnimating = true
        }
    }
}

struct Node: Identifiable, Hashable {
    let id = UUID()
    let position: CGPoint
    let size: CGFloat
    let color: Color
    let text: String
    let detailViews: [AnyView] // 添加一个包含多个子界面的 DetailView 列表

    static func == (lhs: Node, rhs: Node) -> Bool {
        return lhs.id == rhs.id
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}
