import SwiftUI



struct AView: View {
    var img: UIImage

    var body: some View {
        VStack {
            Text("Intro")
                .font(.largeTitle)
            Image(uiImage: img)
                .resizable()
                .aspectRatio(contentMode: .fit)
        }
    }
}

struct BView: View {
    var text: String

    var body: some View {
        VStack {
            Text("BView")
                .font(.largeTitle)
            Text(text)
                .font(.body)
        }
    }
}

struct CView: View {
    var img: UIImage


    var body: some View {
        VStack {
            Text("Evolution of different scripts")
                .font(.largeTitle)
            Image(uiImage: img)
                            .resizable()
                .aspectRatio(contentMode: .fit)

        }
    }
}
struct DView: View {
    var img: UIImage


    var body: some View {
        VStack {
            Text("If you find that the some views are not displayed, please click the navigation button to spread it")
                .font(.system(size:20))
                .fontWeight(.bold)
                .multilineTextAlignment(.leading)
                .lineLimit(nil)
                .minimumScaleFactor(0.5)
            Image(uiImage: img)
                            .resizable()
                .aspectRatio(contentMode: .fit)

        }
    }
}


struct ContentView: View {
    var nodes: [Node]
    var connections: [(Node, Node)]
    init() {
        nodes = createNodes()
        connections = createConnections(nodes: nodes)

    }

    var body: some View {
        GeometryReader { geometry in
            HStack(spacing: 0) {
                NetworkView(nodes: nodes, connections: connections)
                    .frame(width: geometry.size.width / 2)
                VStack(spacing: 0) {
                    ContestView(defaultImage: UIImage(named: "泪.jpg"), textpasstest: "test str")
                        .frame(width: geometry.size.width / 2, height: geometry.size.height / 2)
                    DView(img: UIImage(named: "poster")!)
                        .frame(width: geometry.size.width / 2, height: geometry.size.height / 2)
                }
            }
        }
    }



    // var body: some View {
    //     VStack{
    //         NetworkView(nodes: nodes, connections: connections)
    //         ContestView(defaultImage: UIImage(named: "泪.jpg"), textpasstest: "test str")
    //     }

    //     // ContestView(defaultImage: UIImage(named: "placeholder.jpg"), textpasstest: "test str")



    // }
}



struct ContentView_Previews: PreviewProvider {
static var previews: some View {
      DView(img: UIImage(named: "poster")!)
    }
}



// struct ContentView: View {
//     var body: some View {
//         VStack {
//             Image(systemName: "globe")
//                 .imageScale(.large)
//                 .foregroundColor(.accentColor)
//             Text("Hello, world!")
//             //ContestView(defaultImage: UIImage(named: "泪.jpg"), textpasstest: "test str")
//             ContestView(defaultImage: UIImage(named: "placeholder.jpg"), textpasstest: "test str")


//             // ContestView(textpasstest: "test str")


//         }
//     }
// }
