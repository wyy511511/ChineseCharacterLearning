import Foundation
func createConnections(nodes: [Node]) -> [(Node, Node)] {
    return [
            (nodes[0], nodes[1]),
            (nodes[1], nodes[2]),
            (nodes[2], nodes[0]),
            (nodes[3], nodes[0]),
            (nodes[14], nodes[15]),
            (nodes[15], nodes[16]),
            (nodes[16], nodes[17]),
            (nodes[24], nodes[25]),
            (nodes[29], nodes[25]),
            (nodes[29], nodes[24]),
            (nodes[9], nodes[10]),
            (nodes[1], nodes[30]),
            (nodes[29], nodes[30])

    ]
}

