import SwiftUI

func createNodes() -> [Node] {
    return [
        Node(position: CGPoint(x: 50, y: 100),
                size: 30,
                color: .red,
                text: "泪",//0
                detailViews: [
                    // AnyView(AView(text: "文字介绍1111")),
                    // AnyView(BView(text: "文字22222")),
                    AnyView(ContestView(defaultImage: UIImage(named: "泪.jpg"), textpasstest: "test str"))
                ]),
            Node(position: CGPoint(x: 100, y: 200),
                size: 30,
                color: .green,
                text: "目",//1
                detailViews: [
                    AnyView(AView(img: UIImage(named: "目ex")!)),
                    AnyView(CView(img: UIImage(named: "目his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "目"), textpasstest: "Eye"))
                ]),
            Node(position: CGPoint(x: 232, y: 100),
                size: 30,
                color: .blue,
                text: "水",//2
                detailViews: [
                    AnyView(AView(img: UIImage(named: "水ex")!)),
                    AnyView(CView(img: UIImage(named: "水his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "水"), textpasstest: "Water"))
                ]),
            Node(position: CGPoint(x: 200, y: 140),
                size: 30,
                color: .blue,
                text: "氵",//3
                detailViews: [
                    AnyView(AView(img: UIImage(named: "氵ex")!)),
                    AnyView(CView(img: UIImage(named: "氵his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "氵"), textpasstest: "Water (radical components)"))
                ]),
            Node(position: CGPoint(x: 200, y: 224),
                size: 30,
                color: .blue,
                text: "川",//4
                detailViews: [
                    AnyView(AView(img: UIImage(named: "川ex")!)),
                    AnyView(CView(img: UIImage(named: "川his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "川"), textpasstest: "River"))
                ]),
            Node(position: CGPoint(x: 102, y: 240),
                size: 30,
                color: .yellow,
                text: "山",//5
                detailViews: [
                    AnyView(AView(img: UIImage(named: "山ex")!)),
                    AnyView(CView(img: UIImage(named: "山his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "山"), textpasstest: "Mountain"))
                ]),
            Node(position: CGPoint(x: 180, y: 210),
                size: 30,
                color: .yellow,
                text: "木",//6
                detailViews: [
                    AnyView(AView(img: UIImage(named: "木ex")!)),
                    AnyView(CView(img: UIImage(named: "木his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "木"), textpasstest: "Tree"))
                ]),
            Node(position: CGPoint(x: 190, y: 270),
                size: 30,
                color: .yellow,
                text: "火",//7
                detailViews: [
                    AnyView(AView(img: UIImage(named: "火ex")!)),
                    AnyView(CView(img: UIImage(named: "火his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "火"), textpasstest: "Fire"))
                ]),
            Node(position: CGPoint(x: 60, y: 300),
                size: 30,
                color: .yellow,
                text: "四",//8
                detailViews: [
                    AnyView(AView(img: UIImage(named: "四ex")!)),
                    AnyView(CView(img: UIImage(named: "四his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "四"), textpasstest: "Four"))
                ]),
            Node(position: CGPoint(x: 50, y: 210),
                size: 30,
                color: .yellow,
                text: "日",//9
                detailViews: [
                    AnyView(AView(img: UIImage(named: "日ex")!)),
                    AnyView(CView(img: UIImage(named: "日his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "日"), textpasstest: "Sun"))
                ]),
            Node(position: CGPoint(x: 150, y: 140), 
                size: 30,
                color: .yellow,
                text: "月",//10
                detailViews: [
                    AnyView(AView(img: UIImage(named: "月ex")!)),
                    AnyView(CView(img: UIImage(named: "月his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "月"), textpasstest: "Moon"))
                ]),
            Node(position: CGPoint(x: 70, y: 300),
                size: 30,
                color: .blue,
                text: "云",//11
                detailViews: [
                    AnyView(AView(img: UIImage(named: "云ex")!)),
                    AnyView(CView(img: UIImage(named: "云his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "云"), textpasstest: "Cloud"))
                ]),
            Node(position: CGPoint(x: 70, y: 380),
                size: 30,
                color: .blue,
                text: "雨",//12
                detailViews: [
                    AnyView(AView(img: UIImage(named: "雨ex")!)),
                    AnyView(CView(img: UIImage(named: "雨his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "雨"), textpasstest: "Rain"))
                ]),
            Node(position: CGPoint(x: 85, y: 174),
                size: 30,
                color: .blue,
                text: "雪",//13
                detailViews: [
                    AnyView(AView(img: UIImage(named: "雪ex")!)),
                    AnyView(CView(img: UIImage(named: "雪his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "雪"), textpasstest: "Snow"))
                ]),
            Node(position: CGPoint(x: 100, y: 60),
                size: 30,
                color: .purple,
                text: "象",//14
                detailViews: [
                    AnyView(AView(img: UIImage(named: "象ex")!)),
                    AnyView(CView(img: UIImage(named: "象his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "象"), textpasstest: "Elephant"))
                ]),
            Node(position: CGPoint(x: 120, y: 110),
                size: 30,
                color: .purple,
                text: "鸟",//15
                detailViews: [
                    AnyView(AView(img: UIImage(named: "鸟ex")!)),
                    AnyView(CView(img: UIImage(named: "鸟his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "鸟"), textpasstest: "Bird"))
                ]),
            //  鸟 马 牛 羊
            Node(position: CGPoint(x: 150, y: 140),
                size: 30,
                color: .purple,
                text: "马",//16
                detailViews: [
                    AnyView(AView(img: UIImage(named: "马ex")!)),
                    AnyView(CView(img: UIImage(named: "马his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "马"), textpasstest: "Horse"))
                ]),
            Node(position: CGPoint(x: 150, y: 167),
                size: 30,
                color: .purple,
                text: "牛",//17
                detailViews: [
                    AnyView(AView(img: UIImage(named: "牛ex")!)),
                    AnyView(CView(img: UIImage(named: "牛his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "牛"), textpasstest: "Cow"))
                ]),
            Node(position: CGPoint(x: 135, y: 180),
                size: 30,
                color: .purple,
                text: "羊",//18
                detailViews: [
                    AnyView(AView(img: UIImage(named: "羊ex")!)),
                    AnyView(CView(img: UIImage(named: "羊his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "羊"), textpasstest: "Sheep"))
                ]),
            //肉 田 牙 贝 门 口 耳 鱼 采 鬼 人 眉 下 上
            Node(position: CGPoint(x: 30, y: 210),
                size: 30,
                color: .pink,
                text: "肉",//19
                detailViews: [
                    AnyView(AView(img: UIImage(named: "肉ex")!)),
                    AnyView(CView(img: UIImage(named: "肉his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "肉"), textpasstest: "Meat"))
                ]),
            Node(position: CGPoint(x: 50, y: 258),
                size: 30,
                color: .green,
                text: "田",//20
                detailViews: [
                    AnyView(AView(img: UIImage(named: "田ex")!)),
                    AnyView(CView(img: UIImage(named: "田his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "田"), textpasstest: "Field"))
                ]),
            Node(position: CGPoint(x: 70, y: 123),
                size: 30,
                color: .teal,
                text: "牙",//21
                detailViews: [
                    AnyView(AView(img: UIImage(named: "牙ex")!)),
                    AnyView(CView(img: UIImage(named: "牙his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "牙"), textpasstest: "Tooth"))
                ]),
            Node(position: CGPoint(x: 70, y: 317),
                size: 30,
                color: .mint,
                text: "贝",//22
                detailViews: [
                    AnyView(AView(img: UIImage(named: "贝ex")!)),
                    AnyView(CView(img: UIImage(named: "贝his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "贝"), textpasstest: "Shell"))
                ]),
            Node(position: CGPoint(x: 80, y: 90),
                size: 30,
                color: .brown,
                text: "门",//23
                detailViews: [
                    AnyView(AView(img: UIImage(named: "门ex")!)),
                    AnyView(CView(img: UIImage(named: "门his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "门"), textpasstest: "Door"))
                ]),
            Node(position: CGPoint(x: 65, y:144),
                size: 30,
                color: .teal,
                text: "口",//24
                detailViews: [
                    AnyView(AView(img: UIImage(named: "口ex")!)),
                    AnyView(CView(img: UIImage(named: "口his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "口"), textpasstest: "Mouth"))
                ]),
            Node(position: CGPoint(x: 30, y: 120),
                size: 30,
                color: .teal,
                text: "耳",//25
                detailViews: [
                    AnyView(AView(img: UIImage(named: "耳ex")!)),
                    AnyView(CView(img: UIImage(named: "耳his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "耳"), textpasstest: "Ear"))
                ]),
            Node(position: CGPoint(x: 100, y: 60),
                size: 30,
                color: .purple,
                text: "鱼",//26
                detailViews: [
                    AnyView(AView(img: UIImage(named: "鱼ex")!)),
                    AnyView(CView(img: UIImage(named: "鱼his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "鱼"), textpasstest: "Fish"))
                ]),
            Node(position: CGPoint(x: 200, y: 40),
                size: 30,
                color: .indigo,
                text: "采",//27
                detailViews: [
                    AnyView(AView(img: UIImage(named: "采ex")!)),
                    AnyView(CView(img: UIImage(named: "采his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "采"), textpasstest: "To pick"))
                ]),
            Node(position: CGPoint(x: 50, y: 40),
                size: 30,
                color: .green,
                text: "鬼",//28
                detailViews: [
                    AnyView(AView(img: UIImage(named: "鬼ex")!)),
                    AnyView(CView(img: UIImage(named: "鬼his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "鬼"), textpasstest: "Ghost"))
                ]),
            Node(position: CGPoint(x: 30, y: 140),
                size: 30,
                color: .teal,
                text: "人",//29
                detailViews: [
                    AnyView(AView(img: UIImage(named: "人ex")!)),
                    AnyView(CView(img: UIImage(named: "人his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "人"), textpasstest: "Person"))
                ]),
            Node(position: CGPoint(x: 75, y: 180),
                size: 30,
                color: .teal,
                text: "眉",//30
                detailViews: [
                    AnyView(AView(img: UIImage(named: "眉ex")!)),
                    AnyView(CView(img: UIImage(named: "眉his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "眉"), textpasstest: "Eyebrow"))
                ]),
            Node(position: CGPoint(x: 200, y: 400),
                size: 30,
                color: .green,
                text: "下",//31
                detailViews: [
                    AnyView(AView(img: UIImage(named: "下ex")!)),
                    AnyView(CView(img: UIImage(named: "下his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "下"), textpasstest: "Below"))
                ]),
            Node(position: CGPoint(x: 150, y: 240),  
                size: 30,
                color: .green,
                text: "上",//32
                detailViews: [
                    AnyView(AView(img: UIImage(named: "上ex")!)),
                    AnyView(CView(img: UIImage(named: "上his")!)),
                    AnyView(ContestView(defaultImage: UIImage(named: "上"), textpasstest: "Above"))
                ])



                

                
            
    ]
}

