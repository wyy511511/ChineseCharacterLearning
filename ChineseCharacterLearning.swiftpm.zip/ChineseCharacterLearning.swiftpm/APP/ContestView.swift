import SwiftUI
import VisionKit
import Vision
import PencilKit
import UIKit

struct ContestView: View{
    @State private var originalImageURL: URL?
    @State private var contestantImageURL: URL? = nil
    @State private var contestantImageURLs: [URL] = []
    @State private var ranking: [(contestantIndex: Int, featureprintDistance: Float)] = []
    @State private var showingResults = false
    @State private var isShowingDrawingView = false

    
    @State private var isShowingScanner = false
    @State private var scanMode: ScanMode = .originalImage
    @State private var discardChanges = false

    private var defaultImageURL: URL? {
        guard let defaultImage = defaultImage, let imageData = defaultImage.pngData() else {
            return nil
        }
        let baseURL = FileManager.default.temporaryDirectory
        let imageURL = baseURL.appendingPathComponent(UUID().uuidString).appendingPathExtension("png")
        do {
            try imageData.write(to: imageURL)
            return imageURL
        } catch {
            print("Save image \(imageURL.path) failed.")
            return nil
        }
    }
        

    var textpasstest: String
    var defaultImage: UIImage?

    init(defaultImage: UIImage? = UIImage(named: "placeholder.jpg"), textpasstest: String) {
        self.textpasstest = textpasstest
        self.defaultImage = defaultImage
        if let defaultImage = defaultImage, let url = self.defaultImageURL {
            try? defaultImage.pngData()?.write(to: url)
        }
    }

    var originalImage: UIImage? {
        if let url = originalImageURL {
            return UIImage(contentsOfFile: url.path)
        } else {
            return defaultImage
        }
    }

    enum ScanMode {
        case originalImage
        case contestantImages
    }



    func processImages() {
        guard let originalURL = originalImageURL ?? defaultImageURL else { return }
        guard let originalFPO = featureprintObservationForImage(atURL: originalURL) else { return }
        print(originalFPO.elementCount)
        
        for idx in contestantImageURLs.indices {
            let contestantURL = contestantImageURLs[idx]
            guard let contestantFPO = featureprintObservationForImage(atURL: contestantURL) else { return }
            var distance: Float = 0
            do {
                try contestantFPO.computeDistance(&distance, to: originalFPO)
                ranking.append((contestantIndex: idx, featureprintDistance: distance))
                print(ranking)
                print("Cal distance successfully.")
            } catch {
                print("Cal distance failed. \(error) ")
            }
        }
        
        ranking.sort { (res1, res2) -> Bool in
            return res1.featureprintDistance < res2.featureprintDistance
        }
        
        DispatchQueue.main.async {
            self.showingResults = true
        }
    }

    
    func featureprintObservationForImage(atURL url: URL) -> VNFeaturePrintObservation? {
        let handler = VNImageRequestHandler(url: url)
        let request = VNGenerateImageFeaturePrintRequest()
        do {
            try handler.perform([request])
            return request.results?.first as? VNFeaturePrintObservation
        } catch {
            print("Failed GenerateImageFeaturePrintRequest\(error)")
            return nil
        }
    }


    
    var body: some View {
        NavigationView {
            VStack {
                if let image = originalImage {
                                Image(uiImage: image)
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                            } else {
                                Image("placeholder")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                            }

                Text(textpasstest)
                .font(.body)
                .fontWeight(.bold)

                Text("Notes: If the default image is not displayed, please 1. click the button below to scan the original image / 2. back to the project code page and use the APP PREVIEW small window to experience")
                .font(.system(size: 16))
                .fontWeight(.bold)
                .multilineTextAlignment(.leading)
                .lineLimit(nil)
                .minimumScaleFactor(0.5)


                
                Button(action: {
                    scanMode = .originalImage
                    isShowingScanner = true
                }) {
                    Text("Scan Original Image")
                }
                

 

                Text("Notes: Pease only scan ONE original image. Scan your exercise images to add to the similarity comparison queue!!")
                .font(.system(size: 16))
                .fontWeight(.bold)
                .multilineTextAlignment(.leading)
                .lineLimit(nil)
                .minimumScaleFactor(0.5)


                Button(action: {
                    scanMode = .contestantImages
                    isShowingScanner = true
                }) {
                    Text("Scan Images")
                }



                Text("Draw images to add to the similarity comparison queue!!If you want to draw many images, please click the button below to draw ONE image per time. Every time you draw an image, the image will be added to the list of contestant images. ")
              .font(.system(size: 16))
                .fontWeight(.bold)
                .multilineTextAlignment(.leading)
                .lineLimit(nil)
                .minimumScaleFactor(0.5)




                Button(action: {
                    isShowingDrawingView = true
                }) {
                    Text("Draw Image")
                }
                .sheet(isPresented: $isShowingDrawingView) {
                    NavigationView {
                        VStack {
                            DrawingView(contestantImageURL: $contestantImageURL)
                                .edgesIgnoringSafeArea(.all)
                        }
                        .navigationBarItems(leading: Button("Cancel") {
                            discardChanges = true
                            isShowingDrawingView = false
                        }, trailing: Button("Save and Close") {
                            discardChanges = false
                            isShowingDrawingView = false
                        })
                    }
                    .edgesIgnoringSafeArea(.all)
                    .onDisappear {
                        if let url = contestantImageURL, !discardChanges {
                            contestantImageURLs.append(url)
                            print("contestantImageURLs: \(contestantImageURLs)")
                            processImages() // 在这里调用 processImages()
                        }
                    }
                }
                
                if originalImage != nil && !contestantImageURLs.isEmpty {
                    Button(action: {
                        showingResults = true
                    }) {
                        Text("Congrats! Similarity results are ready! Click ⬇️ to see the results!")
                    }
                }


                if showingResults {
                    NavigationLink("Show Results", destination: ResultsView(originalImageURL: $originalImageURL, contestantImageURLs: $contestantImageURLs, ranking: $ranking))
                }
            }

            .sheet(isPresented: $isShowingScanner) {
                DocumentScanner(scanMode: $scanMode, originalImageURL: $originalImageURL, contestantImageURLs: $contestantImageURLs, showingResults: $showingResults, onImagesProcessed: processImages)
            }
        }
    }
}



            

struct DocumentScanner: UIViewControllerRepresentable {    
    @Binding var scanMode: ContestView.ScanMode
    @Binding var originalImageURL: URL?
    @Binding var contestantImageURLs: [URL]
    @Binding var showingResults: Bool
    var onImagesProcessed: (() -> Void)?
    

    func makeUIViewController(context: Context) -> VNDocumentCameraViewController {
        let documentCameraViewController = VNDocumentCameraViewController()
        documentCameraViewController.delegate = context.coordinator
        return documentCameraViewController
    }
    
    func updateUIViewController(_ uiViewController: VNDocumentCameraViewController, context: Context) {
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(scanMode: $scanMode, originalImageURL: $originalImageURL, contestantImageURLs: $contestantImageURLs, showingResults: $showingResults, onImagesProcessed: onImagesProcessed)
    }


    
    class Coordinator: NSObject, VNDocumentCameraViewControllerDelegate {
        @Binding var scanMode: ContestView.ScanMode
        @Binding var originalImageURL: URL?
        @Binding var contestantImageURLs: [URL]
        @Binding var showingResults: Bool
        
        // weak var parent: DocumentScanner?
        var onImagesProcessed: (() -> Void)?
        //closure

        init(scanMode: Binding<ContestView.ScanMode>, originalImageURL: Binding<URL?>, contestantImageURLs: Binding<[URL]>, showingResults: Binding<Bool>, onImagesProcessed: (() -> Void)?) {
            _scanMode = scanMode
            _originalImageURL = originalImageURL
            _contestantImageURLs = contestantImageURLs
            _showingResults = showingResults
            self.onImagesProcessed = onImagesProcessed
        }

        func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFinishWith scan: VNDocumentCameraScan) {
            switch scanMode {
            case .originalImage:
                originalImageURL = saveImage(scan.imageOfPage(at: 0))
            case .contestantImages:
                for pageIdx in 0..<scan.pageCount {
                    if let url = saveImage(scan.imageOfPage(at: pageIdx)) {
                        contestantImageURLs.append(url)
                    }
                }
            onImagesProcessed?()
            }
            
            controller.dismiss(animated: true)
        }   

        
        private func saveImage(_ image: UIImage) -> URL? {
            guard let imageData = image.pngData() else {
                return nil
            }
            let baseURL = FileManager.default.temporaryDirectory
            let imageURL = baseURL.appendingPathComponent(UUID().uuidString).appendingPathExtension("png")
            do {
                try imageData.write(to: imageURL)
                return imageURL
            } catch {
                print("Save \(imageURL.path) error. Reason: \(error)")
                return nil
            }
        }
    }
}

struct ResultsView: View {
    @Binding var originalImageURL: URL?
    @Binding var contestantImageURLs: [URL]
    @Binding var ranking: [(contestantIndex: Int, featureprintDistance: Float)]

    func similarityPercentage(distance: Float) -> String {
        let similarity = (1 - distance) * 100
        return String(format: "%.2f", similarity)
    }
    
    var body: some View {
        ScrollView {
            VStack {
                if let originalImageURL = originalImageURL, let originalImage = UIImage(contentsOfFile: originalImageURL.path) {
                    Text("Original Image")
                        .font(.title)
                    Image(uiImage: originalImage)
                        .resizable()
                        .scaledToFit()
                }
                
                ForEach(Array(ranking.prefix(4).enumerated()), id: \.offset) { idx, result in
                    if let imageURL = contestantImageURLs[safe: result.contestantIndex], let image = UIImage(contentsOfFile: imageURL.path) {
                        Text("Image \(result.contestantIndex + 1) Similarity \(similarityPercentage(distance: result.featureprintDistance))%")
                            .font(.title)
                        ZStack {
                            Color.red
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color.red, lineWidth: 2)
                                )
                        }

                    }
                }
            }
        }

    }
}




extension Array {
    subscript(safe index: Index) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}


