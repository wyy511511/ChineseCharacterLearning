import SwiftUI

struct DetailView: View {
    var node: Node
    var views: [AnyView]

    var body: some View {
        Text("If the drawing view is not displayed, please click the navigation button below to spread it")
        TabView {
            ForEach(views.indices, id: \.self) { index in
                views[index]
                    .tabItem {
                        Text("View \(index + 1)")
                        .font(.system(size: 30))
                        .bold()

                    }
            }
        }
        .navigationBarTitle("Node \(node.text) Detail")
    }
}
